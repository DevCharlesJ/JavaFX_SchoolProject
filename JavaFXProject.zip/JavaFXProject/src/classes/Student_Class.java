package classes;


// Define Student_Class
public class Student_Class {
	
	// Declare a string attribute to hold the class name, default is "Class"
	private String className = "Class";
	
	// Declare a int attribute to store the number of grades added, start at 0
	private int numGrades = 0;
	
	// Declare a double attribute to hold the final grade, set it to 0
	private double finalGrade = 0.0;
	
	
	// public Student_Class(String) Constructor
	public Student_Class(String name) {
		this.className = name; // Set this class name to given name
	}
	
	
	// Define a method to a grade to the class
	public void addGrade(double grade) {
		
		// References the sum of grades, initially set to (finalGrade * numGrades)
		double sumGrades = (this.finalGrade * this.numGrades);
		
		// Add given grade to the sum of grades
		sumGrades += grade;
		
		// Accumulate this number of grades added by 1
		this.numGrades++;
		
		// Set this finalGrade to (sumGrades / numGrades)
		this.finalGrade = sumGrades / this.numGrades;
	}
	
	// Define a method to return the final grade for the class
	public double getFinalGrade() {return this.finalGrade;}
	
	// Define a method to return the class name
	public String getName() {return this.className;}
}



