/**Version 2.0*/

package application; // import application package


// import external classes
import classes.*;

// import additional necessary java classes and packages
import java.util.*;
import java.util.ArrayList;

// import javafx classes and packages
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.collections.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.text.*;



/* This class is used create a collection of nodes to keep record of,
	for each student */
class Student_NodeCollection {
	
	// Reference a new list of class names as Text nodes
	public List<Text> classTxtList = new ArrayList<>();
	
	/* Reference a new list of grade HBoxes
	   The HBox contains a grade Text Node, and a add grade Button Node*/
	public List<HBox> gradeHBoxList = new ArrayList<>();
	
	// Reference a new ListView to the list of class text nodes
	public ListView<Text> classTxtListView = new ListView<Text>();
	
	// Reference a new ListView to the list of grade HBoxes
	public ListView<HBox> gradeHBoxListView = new ListView<HBox>();
	
	
}



// Main class that extends javafx.application.Application;
public class Main extends Application {
	
	// Create a new Portal object
	Portal portal = new Portal();
	
	// Create a new Gradebook object
	Gradebook gradebook = new Gradebook(portal);
	
	// Create a new list of buttons to hold student button nodes
	List<Button> studentBtnList = new ArrayList<>(); 
    
	// Create a new ListView to display the list of student button nodes
    ListView<Button> studentListView = new ListView<>();
    
    // Create a new barchart to represent the gpa chart
    BarChart gpaChart = createGPAChart();
    
    // Create a Text node to display the cumulative GPA amongst students
    Text txtCGPA = new Text(" No Cumulative GPA");
    
    // Create a Text node to display the number of students
	Text txtNumStudents = new Text("No Students");
	
	// Create a Text node to display the number of classes
	Text txtNumClasses = new Text("No Classes");
	
	
	// Override the start method
	@Override
	public void start(Stage primaryStage) {
		try {
			
			// The main/root main will be of the BorderPane type
			BorderPane mainPane = new BorderPane();
			
			// Create a header for the upcoming student list section
			Label lblStudentList = new Label("Student List");
			lblStudentList.setTextAlignment(TextAlignment.CENTER);
			
			// Create a new VBox to vertically contain the section with the list of students
			VBox vbStudentListSection = new VBox();
			vbStudentListSection.setAlignment(Pos.CENTER); // Center align child nodes
			vbStudentListSection.setSpacing(5); // Set the vertical spacing of each node to 5px
			
			// Set the left position of the Border Pane to the student list section
			mainPane.setLeft(vbStudentListSection);
			
			// Align the student list section to the center of its position
			BorderPane.setAlignment(vbStudentListSection, Pos.CENTER);
			
			// Create a HBox to contain the new student creation section
			HBox hbNewStudentSection = new HBox();
			
			// Set top padding and bottom padding to the new student section
			hbNewStudentSection.setPadding(new Insets(3,0,1,0));
			hbNewStudentSection.setAlignment(Pos.CENTER); // Center align child nodes
			
			// The section will not be used until requested
			hbNewStudentSection.setVisible(false); // Set it's visibility to false
			
			
			// Create a button to request a new student to be added
			Button btnNewStudent = new Button("New Student");
			btnNewStudent.setTextAlignment(TextAlignment.CENTER); // Center align its text
			
			// When clicked, the button will fire an event
			btnNewStudent.setOnMouseClicked(e -> {
				
				// If the new student section is not visible...
				if (!hbNewStudentSection.isVisible()) {
					
					// Make the section visible
					hbNewStudentSection.setVisible(true);
					
					// Change the text of the button to "STOP"
					btnNewStudent.setText("STOP");
				}
				// Else...
				else {
					
					// Make the section invisible
					hbNewStudentSection.setVisible(false);
					
					// Change the text of the button back to normal ("New Student")
					btnNewStudent.setText("New Student");
				}
				
			});
			
			// Create a label to denote the text field where the students new name goes
			Label lblName = new Label("Name: ");
			
			// Create the text field where the students new name goes in
			TextField txtName = new TextField();
			
			// When focused on, the text field will fire if a key is pressed
			txtName.setOnKeyPressed(key -> {
				
				// If the key pressed was the 'Enter' key...
				if (key.getCode().equals(KeyCode.ENTER)) {
					
					String studentName = txtName.getText();
					
					// If given name is not an empty string
					if((studentName.strip()).length() != 0) {
						
						// Call addNewStudent(), passing in the new student name
						addNewStudent(txtName.getText());
						
						// Refresh visual report section
						refreshVisualReport();
						
						// Clear the field for new input
						txtName.clear();
						
					} 
					// Else...
					else {
						// Call 'errorDialog()' to show an error window, passing in the cause
						errorDialog("Student name cannot be empty");
					}
				}
				
			});
			
			// Create a new button with the text "+", secondary option to add a new grade
			Button btnAddStudent = new Button("+");
			btnAddStudent.setPadding(new Insets(0,2,0,2)); // Set Top/Bottom padding to 0, set Left/Right padding to 2
			
			// When clicked, the button will fire an event
			btnAddStudent.setOnMouseClicked(e -> {
				
				String studentName = txtName.getText();
				
				// If given name is not an empty string
				if((studentName.strip()).length() != 0) {
					
					// Call addNewStudent(), passing in the new student name
					addNewStudent(txtName.getText());
					
					// Refresh visual report section
					refreshVisualReport();
					
					// Clear the field for new input
					txtName.clear();
				} 
				// Else...
				else {
					// call 'errorDialog()' to show an error window, passing in the cause
					errorDialog("Student name cannot be empty");
				}
				
			});
			
			
			// Add both the new student label, text field, and button to the new student section
			hbNewStudentSection.getChildren().addAll(lblName, txtName, btnAddStudent);
			
			/* Add the header of the student list section, the student list view,
				the new student button, and the new student section to the main student list section*/
			vbStudentListSection.getChildren().addAll(
					lblStudentList,
					studentListView,
					btnNewStudent,
					hbNewStudentSection
			);
			
			
			/* Create a new VBox for the visual report section, 
				passing in CGPA, NumStudents, NumClasses Text nodes
				and the gpaChart*/
			VBox vbVisualReportSection = new VBox(
				txtCGPA,
				txtNumStudents,
				txtNumClasses,
				gpaChart
			);
			vbVisualReportSection.setPadding(new Insets(5)); // Set 5 px of padding
			vbVisualReportSection.setAlignment(Pos.CENTER); // Center align child nodes
			
			
			// Set visual report section to the center of the mainPane
			mainPane.setCenter(vbVisualReportSection);
			
			
			/* Set a new 600x400 scene with the mainPane as the root
				to the primary stage, and show the primary stage*/
			primaryStage.setScene(new Scene(mainPane, 600,400));
			primaryStage.setTitle(" Visual Student Report"); // Set stage title
			primaryStage.show(); // Show the stage
			
			
		} catch(Exception e) { // If any exceptions occur, catch it
			e.printStackTrace(); // Print the exception's stack trace
		}
	}
	

	
	@SuppressWarnings("all") // The warning showed were not too dangerous, delete this to show warnings
	// This method creates a BarChart for displaying GPA's
	public BarChart createGPAChart() {
		/**Note: This is an experimental GPA Bar Chart, will be changed in newer version*/
		
		/* Here we create a category for the horizontal axis of our bar chart,
		 	which will denote the GPA level of all the students*/
        CategoryAxis xAxis    = new CategoryAxis();
        xAxis.setLabel("GPA"); // Set the category label to "GPA"
        
        /* Create a category for the vertical axis of our bar chart,
	 		which will denote the number of students that have a specific GPA*/
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Number of Students"); // Set the category label to "Number of Students"

        // Create a new Bar Chart object with the specified horizontal and vertical axis
        BarChart barChart = new BarChart(xAxis, yAxis);

        /* Create a XYChart Series,
         	it can be used to display multiple charts. Like for different years*/
        XYChart.Series dataSeries1 = new XYChart.Series();
        dataSeries1.setName("2021");

        /* Add data to dataSeries1, passing in a XYChart.Data object
         * XYChart.Data(x axis data, y axis data)
         * 4 Different data sets are added
         */
        dataSeries1.getData().add(new XYChart.Data("4", 0));
        dataSeries1.getData().add(new XYChart.Data("3"  , 0));
        dataSeries1.getData().add(new XYChart.Data("2"  , 0));
        dataSeries1.getData().add(new XYChart.Data("1 and below"  , 0));
        

        // Add dataSeries1 to the bar chart
        barChart.getData().add(dataSeries1);
        
        return barChart; // Return barChart
	}
	
	
	@SuppressWarnings("all") // The warning showed were not too dangerous, delete this to show warnings
	public void refreshVisualReport() {
		
		// Set CGPA Text Node text to CGPA in gradebook
		txtCGPA.setText("Cumulative GPA: " + gradebook.getCGPA());
		
		// Set NumStudents Text Node text to student count in gradebook
		txtNumStudents.setText(gradebook.getStudentCount() + " Total Students");
		
		// Set NumClasses Text Node text to CGPA in class count
		txtNumClasses.setText("" + gradebook.getClassCount() + " Total Classes");
		
		// Clear all gpaChart data
		gpaChart.getData().clear();
		
		
		int count4 = 0; // References the number of 4 GPAs
		int count3 = 0; // References the number of 3 GPAs
		int count2 = 0; // References the number of 2 GPAs
		int count1orLess = 0; // References the number of 1 or less GPAs
		
		
		// Traverse through each student in Student array
		for(Student student : portal.getStudents()) {
			
			// Using switch-case, accumulate respective count by 1
			switch (student.getGPA()) {
				case 4: count4++; 
						break;
				case 3: count3++;
						break;
				case 2: count2++; 
						break;
				case 1 :count1orLess++;
						break;
				case 0: count1orLess++;
						break;
			}
		}

		
		/* Create a new XYChart Series,
     	it can be used to display multiple charts. Like for different years*/
	    XYChart.Series dataSeries1 = new XYChart.Series();
	    dataSeries1.setName("2021");
	
	    /* Add data to dataSeries1, passing in a XYChart.Data object
         * XYChart.Data(x axis data, y axis data)
         * 4 Different data sets are added
         */
	    dataSeries1.getData().add(new XYChart.Data("4", count4));
	    dataSeries1.getData().add(new XYChart.Data("3"  , count3));
	    dataSeries1.getData().add(new XYChart.Data("2"  , count2));
	    dataSeries1.getData().add(new XYChart.Data("1 and below"  , count1orLess));
	    
	    // Add dataSeries1 to gpaChart
	    gpaChart.getData().add(dataSeries1);
	    
	    
	}
	
	
	// This void method of the generic type, is used to add a node to its respective List and ListView
	public <E> void addToListView(E node, List<E> list, ListView<E> lv) {
		
		// Add the given generic node to its generic list
		list.add(node);
		
		// Create a new generic FXCollections.observableList() object, passing in the given generic list
		ObservableList<E> newObservable = FXCollections.observableList(list);
		
		// Set the items of the given generic list to the new generic observable list
		lv.setItems(newObservable);

	}
		
	
	// This method defines the procedure to create a new errorDialog
	public void errorDialog(String msg) {
		
		// References to size (X,Y) variables for scene
		int sceneX, sceneY = 50;
		
		/* Using (? :) syntax, if (length of message)*10 <= 500,
			scene size X = that, else it cap size to 500*/
		sceneX = (msg.length()*10) <= 500 ? msg.length()*5 : 500;
		
		
		// Create a new BorderPane for the main/root pane 
		BorderPane main = new BorderPane();
		
		// Create a Text node to display the error message
		Text text = new Text(msg);
		text.setTextAlignment(TextAlignment.CENTER); // Center align text
		main.setCenter(text); // Set Text node to the center of the main pane
		
		
		// Create a new stage object
		Stage stage = new Stage();
		stage.setTitle("ERROR"); // Set stage title
		// Set a new sceneX+100 by sceneY Scene object to stage
		stage.setScene(new Scene(main, sceneX+100, sceneY));
		stage.show(); // Show the stage
	}
	
	
	// This void method is used to modularize the addition of a new student
	public void addNewStudent(String name) {
		
		// Add student through portal, passing in student name
		portal.addStudent(name);
		
		// Increase student count within the gradebook
		gradebook.increaseStudentCount();
		
		
		// Create a new button to represent the student for access within the student ListView
		Button btnStudent = new Button(name);
		
		// When clicked, the button for the student will fire an event to open the student window
		btnStudent.setOnMouseClicked(d -> {
			
			/* Open student window, passing in the student object, 
				and a new Student_NodeCollection */
			openStudentWindow(portal.getStudent(name), new Student_NodeCollection());
		});
		
		/* Call the 'addToListView', passing in the necessary parameters,
			to then create a student button to be displayed in the student list view*/
		addToListView(btnStudent, studentBtnList, studentListView);
	}

	
	
	
	// This void method creates a dialog box, used to add grades
	public void addGradeWindow(Student_Class s_cls, Text txtClasssGrade) {
		
		// The main/root pane will be a new Border Pane node
		BorderPane mainPane = new BorderPane();
		
		
		// Create a Label for the field in which the new grade is added
		Label lblGrade = new Label("Enter an decimal 0-100"); // Construct with the text "Enter a decimal"
		
		// Set the label to the top of main pane
		mainPane.setTop(lblGrade);
		BorderPane.setAlignment(lblGrade, Pos.CENTER); // Align the label to the center of its position
		
		// Create the text field for the new grade input
		TextField txtGrade = new TextField();
		txtGrade.setMaxWidth(80); // Set its max width to 80px
		mainPane.setCenter(txtGrade); // Set the text field to the center of the main pane
		
		// When focused on, an event will be fired if a key is pressed
		txtGrade.setOnKeyPressed(key -> {
			
			// If the KeyCode of the key pressed is the Key Code of the 'Enter' key
			if (key.getCode().equals(KeyCode.ENTER)) {
				// Using a try-catch block...
				try {
					// Attempt to parse a double value from grade text node
					double grade = Double.parseDouble(txtGrade.getText());
					
					// Check if grade is between 0 - 100
					if(grade >=0 && grade <= 100) {
						
						// Call Student_Class.addGrade() to add given grade
						s_cls.addGrade(grade);
						
						// Set the class grade text node to the updated final grade
						txtClasssGrade.setText("" + s_cls.getFinalGrade());
						
						// Refresh visual report section
						refreshVisualReport();
						
					} 
					// Else...
					else {
						
						// Call 'errorDialog()' to show an error window, passing in the cause
						errorDialog("Expected grade in range 0-100");
					}
				} catch(NumberFormatException nfe){ // Catch NumberFormatException
					
					// Call 'errorDialog()' to show an error window, passing in the cause
					errorDialog("\"" + txtGrade.getText() + "\" is not a decimal");
				}
				
				// Clear field for new input
				txtGrade.clear();
			}
			
		});
		BorderPane.setAlignment(txtGrade,Pos.CENTER); // Align the label to the center of its position
		
		// Create a new button to also add the grade
		Button btnAdd = new Button("Add"); // Construct with the text "Add"
		mainPane.setBottom(btnAdd); // Set the button to the bottom of the main pane
		
		// When clicked, the button fires an event
		btnAdd.setOnMouseClicked(e -> {
			
			// Using a try-catch block...
			try {
				// Attempt to parse a double value from grade text node
				double grade = Double.parseDouble(txtGrade.getText());
				
				// Check if grade is between 0 - 100
				if(grade >=0 && grade <= 100) {
					
					// call Student_Class.addGrade() to add given grade
					s_cls.addGrade(grade);
					
					// Set the class grade text node to the updated final grade
					txtClasssGrade.setText("" + s_cls.getFinalGrade());
					
					// Refresh visual report section
					refreshVisualReport();
					
				}
				// Else..
				else {
					
					// Call 'errorDialog()' to show an error window, passing in the cause
					errorDialog("Expected grade in range 0-100");
				}
				
			} catch(NumberFormatException nfe){ // Catch NumberFormatException
				
				// Call errorDialog(), passing in an error msg
				errorDialog("\"" + txtGrade.getText() + "\" is not a decimal");
			}
			
			// Clear field for new input
			txtGrade.clear();
		});
		BorderPane.setAlignment(btnAdd,Pos.CENTER); // Align the button to the center of its position
		
		
		// Create a new stage object
		Stage stage = new Stage();
		stage.setTitle("Enter grade"); // Set the title to "Enter grade"
		
		// Set the scene to a new 200x100 Scene object with mainPane as the root
		stage.setScene(new Scene(mainPane,250,100)); 
		stage.show(); // Show the stage
	}
	
	
	// This void method builds a row of class information, using two ListViews
	public void buildClassRow(Student_Class s_cls, Student_NodeCollection nodeCollection ) {
		
		// Reference the class List<Text> and ListView<Text> from nodeCollection
		List<Text> classTxtList = nodeCollection.classTxtList;
		ListView<Text> classTxtListView = nodeCollection.classTxtListView;
		
		// Reference the grade List<HBox> and ListView<HBox> from nodeCollection
		List<HBox> gradeHBoxList = nodeCollection.gradeHBoxList;
		ListView<HBox> gradeHBoxListView = nodeCollection.gradeHBoxListView;
		
		
		
		// Create a new text node with the class name as it's text
		Text txtClassName = new Text(s_cls.getName());
		
		// Call addToListView() to add the text to its ListView
		addToListView(txtClassName, classTxtList, classTxtListView);
		
		// Create a new text node with the final grade of the class as the text
		Text txtGrade = new Text("" + s_cls.getFinalGrade());
		
		// Create a new button with the text "+", which is used to add a new grade
		Button btnAddGrade = new Button("+");
		btnAddGrade.setPadding(new Insets(0,2,0,2)); // Set Top/Bottom padding to 0, set Left/Right padding to 2
		
		// When clicked, the button will fire an event to open the dialog to add a new grade
		btnAddGrade.setOnMouseClicked(e -> {
			
			// Call 'addGradeWindow()' passing in the class obj and grade Text Node
			addGradeWindow(s_cls, txtGrade);
		});
		
		// Create a HBox to contain the class row, passing in the grade text, and add button nodes
		HBox hbClassRow = new HBox(txtGrade, btnAddGrade);
		hbClassRow.setAlignment(Pos.CENTER); // Center align child nodes
		hbClassRow.setSpacing(20); // Set the horizontal spacing of the nodes to 20px
		
		// Call addToListView() to add the box to its ListView
		addToListView(hbClassRow, gradeHBoxList, gradeHBoxListView);
		
		
	}
	
	
	/* This void method is used to open the student window/portal,
	 	It exposes the student's information, like their list classes in this case*/
	public void openStudentWindow(Student student, Student_NodeCollection nodeCollection) {
		
		// Reference the class Text ListView from nodeCollection
		ListView<Text> classTxtListView = nodeCollection.classTxtListView;
		
		// Reference the class Text ListView from nodeCollection
		ListView<HBox> gradeHBoxListView = nodeCollection.gradeHBoxListView;
		
		for(Student_Class s_cls : student.getClasses()) {
			
			// Call the buildClassRow() to build a class row, passing in the class, and student node collection
			buildClassRow(s_cls, nodeCollection);
		}
		
		// Reference the student's name
		String name = student.getName();
		
		// The main/root pane will be a new Border Pane node
		BorderPane mainPane = new BorderPane();
		
		/* Create a new VBox to contain the list of classes section
		 This section the list of classes a student has*/
		VBox vbClassListSection = new VBox();
		vbClassListSection.setAlignment(Pos.CENTER); // Center align the box in its position
		vbClassListSection.setSpacing(5); // Set the vertical spacing of child nodes to 5px
		
		// Set the class list section to the center position of the main pane 
		mainPane.setCenter(vbClassListSection);
		
		
		/* Create a new HBox to contain the new class section
		 	This section is where the user can add a new class to the student*/
		HBox hbNewClassSection = new HBox();
		// Separate this section from the list of classes section, set top padding to 10px
		hbNewClassSection.setPadding(new Insets(3,0,1,0));
		hbNewClassSection.setAlignment(Pos.CENTER); // Align the section to center of its position in the mainPane
		
		// This section will not be used until requested
		hbNewClassSection.setVisible(false); // Set it's visibility to false
		
		
		// Create a new header label for the frame of class names
		Label lblClassNames = new Label("Class"); // Construct with the text "Class"
		lblClassNames.setTextAlignment(TextAlignment.CENTER); // Center align the text
		
		// Create a new header label for the frame of class grades
		Label lblClassGrades = new Label("Grade"); // Construct with the text "Grade"
		lblClassGrades.setTextAlignment(TextAlignment.CENTER); // Center align the text
		
		
		// Create a new VBox containing the class names header and the class ListView
		VBox vbClassNamesFrame = new VBox(lblClassNames, classTxtListView);
		vbClassNamesFrame.setSpacing(5); // Set the vertical spacing of child nodes to 5px
		vbClassNamesFrame.setAlignment(Pos.CENTER); // Align the box to the center of its position in the mainPane
		
		VBox vbClassGradesFrame = new VBox(lblClassGrades, gradeHBoxListView);
		vbClassGradesFrame.setSpacing(5); // Set the vertical spacing of child nodes to 5px
		vbClassGradesFrame.setAlignment(Pos.CENTER); // Align the box to the center of its position in the mainPane
		
		// Create a new HBox to frame the both the frame of class names, and the frame of class grades
		HBox hbClassListFrame = new HBox(vbClassNamesFrame, vbClassGradesFrame);
		hbClassListFrame.setAlignment(Pos.CENTER); // Align the box to the center of its position in the mainPane
		
		
		// Create a new button to be used to add a new class
		Button btnAddClass = new Button("Add Class"); // Construct with the text "Add Class"
		btnAddClass.setTextAlignment(TextAlignment.CENTER); // Center align the text
		
		// When clicked, the button will fire an event
		btnAddClass.setOnMouseClicked(e -> {
			
			// If the new class section is not visible
			if (!hbNewClassSection.isVisible()) {
				
				// Make the new class section visible
				hbNewClassSection.setVisible(true);
				
				// Set the text of the button to "STOP"
				btnAddClass.setText("STOP");
			}
			// Else...
			else {
				
				// Make the new class section invisible
				hbNewClassSection.setVisible(false);
				
				// Change the text of the button back to normal ("Add Class")
				btnAddClass.setText("Add Class");
			}
		});
		
		
		// Here we create a new label to denote where to enter the name of the new class
		Label lblName = new Label("Name: "); // Construct with the text "Name"
		
		// Create a new Text Field for which the name of the new class is inputed
		TextField txtName = new TextField();
		
		// When focused on, the field will fire an event if a key is pressed
		txtName.setOnKeyPressed(key -> {
			
			// If the key pressed was the 'Enter' key
			if (key.getCode().equals(KeyCode.ENTER)) {
				
				// Reference the given class name
				String className = txtName.getText();

				// If given name is not an empty string
				if((className.strip()).length() != 0) {
					
					// Add class to student
					student.addClass(className);
					
					// Increase class count in gradebook
					gradebook.increaseClassCount();
					
					/* Call 'buildClassRow()' to build a ListView row, 
						passing in the class obj and nodeCollection*/
					buildClassRow(student.getClass(className), nodeCollection);
					
					// Refresh visual report section
					refreshVisualReport();
					
					// Clear the class name text field node
					txtName.clear();
				} 
				// Else...
				else {
					// Call 'errorDialog()' to show an error window, passing in the cause
					errorDialog("Class name cannot be empty");
				}
				
				
			}
			
		});
		
		// Create a new button to add a new class, secondary option
		Button btnSecondaryAddClass = new Button("+"); // Construct with the text "+"
		btnSecondaryAddClass.setPadding(new Insets(0,2,0,2)); // Set Top/Bottom padding to 0, set Left/Right padding to 2
		
		// When clicked, the button will fire an event
		btnSecondaryAddClass.setOnMouseClicked(e -> {
			
			// Reference the given class name
			String className = txtName.getText();
			
			// If given name is not an empty string
			if((className.strip()).length() != 0) {
				
				// Add class to student
				student.addClass(className);
				
				// Increase class count in gradebook
				gradebook.increaseClassCount();
				
				/* Call 'buildClassRow()' to build a ListView row, 
					passing in the class obj and nodeCollection*/
				buildClassRow(student.getClass(className), nodeCollection);
				
				// Refresh visual report section
				refreshVisualReport();
				
				// Clear the class name text field node
				txtName.clear();
			} 
			// Else...
			else {
				// Call 'errorDialog()' to show an error window, passing in the cause
				errorDialog("Class name cannot be empty");
			}
			
		});
		
		// Now, we add both the label, text field, secondary button for the new class name to the new class section
		hbNewClassSection.getChildren().addAll(lblName, txtName, btnSecondaryAddClass);
		
		/* Then, we add the frame for the list of classes, the add class button,
			and the new class section to the class list section */
		vbClassListSection.getChildren().addAll(
				hbClassListFrame,
				btnAddClass,
				hbNewClassSection
		);
		
		
		classTxtListView.setMaxWidth(300); // Set the max width of the class ListView to 300
		classTxtListView.setBorder(Border.EMPTY); // Set the border of the class ListView to Empty
		
		gradeHBoxListView.setMaxWidth(100); // Set the max width of the grade ListView to 100
		
		
		// Finally, we create a new stage object
		Stage stage = new Stage();
		stage.setTitle(name + "'s Classes"); // Set the title of the stage to "<Student name>'s Classes"
		stage.setScene(new Scene(mainPane,400,400)); // Set the scene of the stage to a new 400x400 Scene with the main Pane as its root
		stage.show(); // Show the stage
	}
		
	
	// This is the main method
	public static void main(String[] args) {
		launch(args); // launch the application
	}
}

