package classes;
import java.util.ArrayList; // import ArrayList


// Define the Portal Class
public class Portal {
	
	// Declare an array list of student objects
	private ArrayList<Student> students = new ArrayList<Student>();
	
	// Define a method to add student to portal
	public void addStudent(String name) {
		
		// Add new Student to array
		students.add(new Student(name));
	}
	
	
	// Define a method to return a student, given a name
	public Student getStudent(String name) {
		
		// For each student in student array
		for(Student student : students) {
			
			// If the students name equlas the given name
			if (student.getName().compareTo(name) == 0)
				return student; // Return student
		}
		
		return null; // Student not found, return null
	}
	
	// Define a method to return the array of students
	public ArrayList<Student> getStudents(){return students;}
	
}