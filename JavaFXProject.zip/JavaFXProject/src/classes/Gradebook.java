package classes;
import java.util.ArrayList; // import ArrayList


// Define 'Gradebook' Class
public class Gradebook{
	
	// Declare private attribute to hold the cumulative GPA
	private int cumulativeGPA = 0;
	
	// Declare a private attribute to keep count of students, start at 0
	private int numTotalStudents = 0;
	
	// Declare an private attribute to keep count of classes, start at 0
	private int numTotalClasses = 0;
	
	// Declare a reference to a new given Portal object
	protected Portal portal;
	
	
	// public (Portal) arg Gradebook Constructor
	public Gradebook(Portal portal){
		this.portal = portal; // Set this portal to given portal object
	}
	
	
	
	
	// Define a method to calculate the cumulative GPA
	public void calculateCGPA() {
		
		// Declare ArrayList of Student objects
		ArrayList<Student> students = portal.getStudents();
		
		// Declare 'sumGrades' and 'averageGrade', set to 0.0
		double sumGrades = 0.0;
		double averageGrade = 0.0;
		
		// For each Student 'student' in 'students'
		for (Student student : students) {

			// and For each Student_Class 's_cls' in 'student.getClasses()'
			for (Student_Class s_cls : student.getClasses()) {
				sumGrades += s_cls.getFinalGrade(); // Accumulate final grades
			}
		}
		
		// Calculate average grade
		averageGrade = sumGrades / students.size();
		
		// Determine a GPA using the simplest formula
		// (90+ ~> 4, 80+ ~> 3, 70+ ~> 2, 60+ ~> 1, 50+ ~> 0)
		
		// If average grade is greater than 90
		if (averageGrade >= 90) {
			cumulativeGPA = 4; // Set cumulativeGPA to 4
		}
		// If average grade is greater than 80
		else if (averageGrade >= 80) {
			cumulativeGPA = 3; // Set cumulativeGPA to 3
		}
		// If average grade is greater than 70
		else if (averageGrade >= 70) {
			cumulativeGPA = 2; // Set cumulativeGPA to 2
		}
		// If average grade is greater than 60
		else if (averageGrade >= 60) {
			cumulativeGPA = 1; // Set cumulativeGPA to 1
		}
		// Else...
		else {
			cumulativeGPA = 0; // Set cumulativeGPA to 0
		}
	}
	
	// Define a method to increase student count by 1
	public void increaseStudentCount() {
		numTotalStudents++; // Accumulate numTotalStudents
	}
	
	// Define a method to return numTotalStudents
	public int getStudentCount() {return numTotalStudents;}
	
	// Define a method to increase class count by 1
	public void increaseClassCount() {
		numTotalClasses++; // Accumulate numTotalClasses
	}
	
	// Define a method to return numTotalClasses
	public int getClassCount() {return numTotalClasses;}
	
	// Define a method to get the cumulative GPA
	public int getCGPA() {
		
		// Calculate and Return 'cumulativeGPA'
		calculateCGPA();
		return cumulativeGPA;
	}

}


