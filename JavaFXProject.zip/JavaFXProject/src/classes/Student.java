package classes;

import java.util.ArrayList; // import ArrayList


// Define Student class
public class Student {
	
	// Declare a String attribute to hold this students name, default is "Student"
	private String studentName = "Student";
	
	// Declare an array list of classes this student has
	private ArrayList<Student_Class> classes = new ArrayList<Student_Class>();
	
	// Declare an int attribute to store this student's gpa
	private int gpa = 0;
	
	
	// Define a Student(String) Constructor
	public Student(String name) {
		this.studentName = name; // Set this students name to given name
	}
	
	
	// Define a method to add a class to this student
	public void addClass(String name) {
		
		// Add class the student
		classes.add(new Student_Class(name));
	}
	
	// Define a method to calculate the students GPA
	//	Note: Class credits are not accounted for, 
	//			so a simple GPA formula will be implemented
	private void calculateGPA() {
		
		// Reference the sum of grades and the average grade, set both to 0.0
		double sumGrades = 0.0;
		double averageGrade = 0.0;
		
		// For each Student_Class in classes
		for (Student_Class s_cls : classes) {
			// Add final grade to the sum of grades
			sumGrades += s_cls.getFinalGrade();
		}
		
		// Calculate the average grade
		averageGrade = sumGrades/classes.size();
		
		// Determine a GPA using the simplest formula
		// (90+ ~> 4, 80+ ~> 3, 70+ ~> 2, 60+ ~> 1, 50+ ~> 0)
		
		// If average grade is greater than 90
		if (averageGrade >= 90) {
			this.gpa = 4; // Set this gpa to 4
		}
		// If average grade is greater than 80
		else if (averageGrade >= 80) {
			this.gpa = 3; // Set this gpa to 3
		}
		// If average grade is greater than 70
		else if (averageGrade >= 70) {
			this.gpa = 2; // Set this gpa to 2
		}
		// If average grade is greater than 60
		else if (averageGrade >= 60) {
			this.gpa = 1; // Set this gpa to 1
		}
		// Else...
		else {
			this.gpa = 0; // Set this gpa to 0
		}
	}
	
	// Define a method to return this student's gpa
	public int getGPA() {
		
		//Calculate the GPA and return it
		calculateGPA(); 
		return this.gpa;
	}
	
	// Define a method to return this student's list of classes
	public ArrayList<Student_Class> getClasses(){return this.classes;}
	
	
	// Define a method to return this student's name
	public String getName() {return this.studentName;} 
	
	// Define a method to return a class from student, given a name
	public Student_Class getClass(String name) {
		
		// For each Student_Class in student's class array
		for(Student_Class s_cls : classes) {
			
			// If the class's name equals given name
			if (s_cls.getName().compareTo(name) == 0)
				return s_cls; // Return Student_Class
		}
		
		return null; // Student_Class not found, return null
	}
}
